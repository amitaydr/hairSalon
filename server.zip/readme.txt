hi, here are some operating specifications for this project. 
I ran this project on localhost. 
first, set up a mySQL database for the project as explained in "mySQL instructions for HairSalon.txt"
run the server on a tomcat server (I did it via eclipse), 
and then connect through Chrome to localhost:8080/HairSalon/index.html
if you are having problems running it please contact me

have a good day!
Amitay Dror


