package hairSalon;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import db.DBconnector;

import org.json.JSONException;
import org.json.*;


/**
 * Servlet implementation class SalonServer
 */
@WebServlet("/SalonServer")
public class SalonServer extends HttpServlet {
	private static final long serialVersionUID = 1L;
    DBconnector dbcon;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SalonServer() {
        super();
        dbcon = new DBconnector();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String fName = request.getParameter("fName");
		String lName = request.getParameter("lName");
		String service = request.getParameter("service");
		String datetime = request.getParameter("time");
		PrintWriter out = response.getWriter();
		out.println("<html><title>confirmation page</title><body><h1 align='center'>Thank you for choosing wix hair salon!</h1>"+
				"<br>"+fName+" "+lName+" , your booking for: "+service+ " at: "+datetime+" is approved.<br> have a nice day! </body></html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		StringBuilder sb = new StringBuilder();
        BufferedReader br = request.getReader();
        String str = null;
        while ((str = br.readLine()) != null) {
            sb.append(str);
        }
        JSONObject jObj;
        String name="not initialized";
        try {
			jObj = new JSONObject(sb.toString());
			name = jObj.getString("name");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
 
        response.setContentType("text/plain");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write("hello from java. you entered : " + name);
		  
	}

}
